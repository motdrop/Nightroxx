const defaults=[
{id:"1",name:"NIGHTROX",role:"THEBOSSHIGHHEAD",image:"images/background.png",facebook:"",instagram:""},
{id:"2",name:"Member 02",role:"VERYHIGH.WAY",image:"images/background.png",facebook:"",instagram:""},
{id:"3",name:"Member 03",role:"GANGLIST.WAY",image:"images/background.png",facebook:"",instagram:""}
];
const get=()=>{try{const x=localStorage.getItem("nightrox_members");if(x)return JSON.parse(x);localStorage.setItem("nightrox_members",JSON.stringify(defaults));return defaults}catch{return defaults}};
const esc=x=>String(x??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
let role="ALL";
const grid=document.querySelector("#grid"), search=document.querySelector("#search"), count=document.querySelector("#memberCount"), empty=document.querySelector("#empty");


const channel = new BroadcastChannel('nightrox_sync');
channel.onmessage = () => render();
function render(){
 const q=search.value.trim().toLowerCase(), all=get();
 const list=all.filter(m=>(role==="ALL"||m.role===role)&&m.name.toLowerCase().includes(q));
 count.textContent=all.length; empty.classList.toggle("hidden",!!list.length);
 grid.innerHTML=list.map(m=>`<article class="member">
 <img class="member-image" src="${esc(m.image||"images/background.png")}" alt="${esc(m.name)}">
 <div class="member-body"><h3 class="member-name">${esc(m.name)}</h3><div class="member-role">${esc(m.role)}</div>
 <div class="socials">${m.facebook?`<a href="${esc(m.facebook)}" target="_blank" rel="noopener">FACEBOOK</a>`:""}${m.instagram?`<a href="${esc(m.instagram)}" target="_blank" rel="noopener">INSTAGRAM</a>`:""}</div></div></article>`).join("");
 grid.querySelectorAll(".member-image").forEach(img=>img.onclick=()=>{document.querySelector("#modalImg").src=img.src;document.querySelector("#modal").classList.remove("hidden")});
}
document.querySelector("#filters").onclick=e=>{const b=e.target.closest(".filter");if(!b)return;role=b.dataset.role;document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");render()};
search.oninput=render;window.onstorage=render;
document.querySelector("#closeModal").onclick=()=>document.querySelector("#modal").classList.add("hidden");
document.querySelector("#modal").onclick=e=>{if(e.target.id==="modal")e.currentTarget.classList.add("hidden")};
render();
