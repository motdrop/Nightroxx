// NIGHTROX Admin Panel JavaScript
// ========================================

// Configuration
const RTDB_URL = 'https://fahpathanlady-default-rtdb.firebaseio.com/nightrox_members.json';
const STORAGE_KEY = 'nightrox_roster_v3';
const ADMIN_SESSION_KEY = 'nightrox_admin_session';


const ADMIN_EMAIL_HASH = '4746f2f71d4dd51eaa17cbbdc7819efb71cd89797f071392773273bb812b4f80';
const ADMIN_PASSWORD_HASH = '0cb50f1bc5e6e5d3e927a7aefcdd634db85de625c150cd59ecea4f2ee1bc2a6d';

// State
let members = [];
let isLoggedIn = false;
let editingMemberId = null;

// Utility Functions
function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, ch => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[ch]);
}

function showToast(message) {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// SHA-256 Hash Function
async function sha256(message) {
    try {
        const msgBuffer = new TextEncoder().encode(message);
        const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    } catch {
        return '';
    }
}

// Image Upload Handler
function handleImageUpload(input) {
    const file = input.files && input.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
        showToast('⚠️ กรุณาเลือกไฟล์รูปภาพ');
        return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {
            // Resize image
            const canvas = document.createElement('canvas');
            const maxDim = 400;
            let width = img.width;
            let height = img.height;

            if (width > height) {
                if (width > maxDim) {
                    height = Math.round((height * maxDim) / width);
                    width = maxDim;
                }
            } else {
                if (height > maxDim) {
                    width = Math.round((width * maxDim) / height);
                    height = maxDim;
                }
            }

            canvas.width = width;
            canvas.height = height;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(img, 0, 0, width, height);

            // Convert to base64
            const base64 = canvas.toDataURL('image/jpeg', 0.85);

            // Update preview and clear URL input
            document.getElementById('img-preview').src = base64;
            document.getElementById('member-img-url').value = base64;

            showToast('✅ รูปภาพอัพโหลดสำเร็จ!');
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

// Image URL Preview
document.addEventListener('input', function(e) {
    if (e.target && e.target.id === 'member-img-url') {
        const url = e.target.value.trim();
        if (url) {
            document.getElementById('img-preview').src = url;
        }
    }
});

// Authentication
function checkAuth() {
    try {
        isLoggedIn = sessionStorage.getItem(ADMIN_SESSION_KEY) === '1';
    } catch {
        isLoggedIn = false;
    }

    if (isLoggedIn) {
        showDashboard();
    } else {
        showLogin();
    }
}

function showLogin() {
    document.getElementById('login-section').classList.remove('hidden');
    document.getElementById('dashboard-section').classList.add('hidden');
}

function showDashboard() {
    document.getElementById('login-section').classList.add('hidden');
    document.getElementById('dashboard-section').classList.remove('hidden');
    loadMembers();
}

async function handleLogin(event) {
    event.preventDefault();

    const email = document.getElementById('admin-email').value.trim();
    const password = document.getElementById('admin-password').value.trim();
    const errorEl = document.getElementById('admin-error');

    // Hash credentials
    const emailHash = await sha256(email);
    const passwordHash = await sha256(password);

    // Verify
    if (emailHash === ADMIN_EMAIL_HASH && passwordHash === ADMIN_PASSWORD_HASH) {
        isLoggedIn = true;
        try {
            sessionStorage.setItem(ADMIN_SESSION_KEY, '1');
        } catch {}
        errorEl.textContent = '';
        showToast('✅ เข้าสู่ระบบสำเร็จ!');
        showDashboard();
    } else {
        errorEl.textContent = 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
    }

    return false;
}

function logout() {
    isLoggedIn = false;
    try {
        sessionStorage.removeItem(ADMIN_SESSION_KEY);
    } catch {}
    showToast('✅ ออกจากระบบเรียบร้อย');
    showLogin();
    document.getElementById('login-form').reset();
}

// Member Management
function normalizeMember(item, index) {
    if (!item || !item.name) return null;
    let role = String(item.role || 'member').toLowerCase().trim();
    if (role === 'founder' || role === 'theboss') role = 'founder';
    else if (role === 'leader' || role === 'veryhigh') role = 'leader';
    else role = 'member';

    return {
        id: String(item.id || `m-${index || Date.now()}`),
        name: String(item.name).trim(),
        role,
        img: item.img || '',
        fb: item.fb || '',
        ig: item.ig || '',
        music: item.music || ''
    };
}

async function loadMembers() {
    try {
        const res = await fetch(`${RTDB_URL}?t=${Date.now()}`);
        if (res.ok) {
            const data = await res.json();
            if (Array.isArray(data)) {
                members = data.map(normalizeMember).filter(Boolean);
                try {
                    localStorage.setItem(STORAGE_KEY, JSON.stringify(members));
                } catch {}
                renderMembers();
            } else if (data === null) {
                // Empty database, load from localStorage
                try {
                    const saved = localStorage.getItem(STORAGE_KEY);
                    if (saved) {
                        members = JSON.parse(saved).map(normalizeMember).filter(Boolean);
                        renderMembers();
                    }
                } catch {}
            }
        }
    } catch (err) {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);
            if (saved) {
                members = JSON.parse(saved).map(normalizeMember).filter(Boolean);
                renderMembers();
            }
        } catch {}
    }
}

function renderMembers() {
    const list = document.getElementById('members-list');
    const count = document.getElementById('members-count');

    if (!list) return;

    count.textContent = `[${members.length}]`;

    if (members.length === 0) {
        list.innerHTML = '<div style="text-align: center; padding: 60px 20px; color: var(--text-muted); font-size: 0.95rem;"><i class="fas fa-users" style="font-size: 3rem; margin-bottom: 16px; opacity: 0.3; display: block;"></i>ยังไม่มีสมาชิก<br><span style="font-size: 0.8rem; opacity: 0.6; margin-top: 8px; display: block;">เพิ่มสมาชิกคนแรกได้เลย</span></div>';
        return;
    }

    const ROLE_NAMES = {
        founder: 'FOUNDER',
        leader: 'LEADER',
        member: 'GANGLIST'
    };

    list.innerHTML = members.map(m => {
        const img = m.img || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23333" width="100" height="100"/><text y="50%25" x="50%25" text-anchor="middle" dy=".3em" fill="%23fff" font-size="50">👤</text></svg>';
        const roleName = ROLE_NAMES[m.role] || m.role.toUpperCase();

        return `
            <div class="member-item">
                <div class="member-info">
                    <img src="${img}" alt="${escapeHtml(m.name)}" class="member-avatar" onerror="this.src='data:image/svg+xml,<svg xmlns=\\"http://www.w3.org/2000/svg\\" viewBox=\\"0 0 100 100\\"><rect fill=\\"%23333\\" width=\\"100\\" height=\\"100\\"/><text y=\\"50%25\\" x=\\"50%25\\" text-anchor=\\"middle\\" dy=\\".3em\\" fill=\\"%23fff\\" font-size=\\"50\\">👤</text></svg>'">
                    <div class="member-details">
                        <h4>${escapeHtml(m.name)}</h4>
                        <span>${roleName}</span>
                    </div>
                </div>
                <div class="member-actions">
                    <button class="btn-icon" onclick="editMember('${m.id}')" title="แก้ไข">
                        <i class="fas fa-pen"></i>
                    </button>
                    <button class="btn-icon" onclick="deleteMember('${m.id}')" title="ลบ">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

async function saveMembers() {
    // Save to localStorage
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(members));
    } catch {}

    // Save to Firebase
    try {
        const res = await fetch(RTDB_URL, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(members)
        });
        if (res.ok) {
            showToast('✅ บันทึกข้อมูลสำเร็จ!');
        }
    } catch (err) {
        showToast('⚠️ เกิดข้อผิดพลาดในการบันทึก');
    }
}

async function handleAddMember(event) {
    event.preventDefault();

    const name = document.getElementById('member-name').value.trim();
    const role = document.getElementById('member-role').value;
    const img = document.getElementById('member-img-url').value.trim();
    const fb = document.getElementById('member-fb').value.trim();
    const ig = document.getElementById('member-ig').value.trim();
    const music = document.getElementById('member-music').value.trim();

    if (!name) {
        showToast('⚠️ กรุณากรอกชื่อสมาชิก');
        return false;
    }

    if (editingMemberId) {
        // Update existing member
        const index = members.findIndex(m => m.id === editingMemberId);
        if (index !== -1) {
            members[index] = {
                id: editingMemberId,
                name,
                role,
                img,
                fb,
                ig,
                music
            };
            showToast('✅ อัพเดทข้อมูลสำเร็จ!');
        }
        cancelEdit();
    } else {
        // Add new member
        const newMember = {
            id: 'm-' + Date.now(),
            name,
            role,
            img,
            fb,
            ig,
            music
        };

        members.unshift(newMember);
        showToast('✅ เพิ่มสมาชิกสำเร็จ!');
        document.getElementById('add-member-form').reset();
        document.getElementById('img-preview').src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23333" width="100" height="100"/><text y="50%25" x="50%25" text-anchor="middle" dy=".3em" fill="%23fff" font-size="50">👤</text></svg>';
    }

    await saveMembers();
    renderMembers();

    return false;
}

function editMember(id) {
    const member = members.find(m => m.id === id);
    if (!member) return;

    editingMemberId = id;

    document.getElementById('member-name').value = member.name;
    document.getElementById('member-role').value = member.role;
    document.getElementById('member-img-url').value = member.img;
    document.getElementById('member-fb').value = member.fb;
    document.getElementById('member-ig').value = member.ig;
    document.getElementById('member-music').value = member.music || '';

    if (member.img) {
        document.getElementById('img-preview').src = member.img;
    }

    document.getElementById('form-title').textContent = 'EDIT MEMBER';
    document.getElementById('submit-btn-text').textContent = 'UPDATE MEMBER';
    document.getElementById('cancel-edit-btn').classList.remove('hidden');

    showToast('📝 กำลังแก้ไขข้อมูล');
    document.getElementById('member-name').focus();
    document.getElementById('add-member-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function cancelEdit() {
    editingMemberId = null;
    document.getElementById('add-member-form').reset();
    document.getElementById('img-preview').src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect fill="%23333" width="100" height="100"/><text y="50%25" x="50%25" text-anchor="middle" dy=".3em" fill="%23fff" font-size="50">👤</text></svg>';
    document.getElementById('form-title').textContent = 'ADD MEMBER';
    document.getElementById('submit-btn-text').textContent = 'ADD MEMBER';
    document.getElementById('cancel-edit-btn').classList.add('hidden');
}

async function deleteMember(id) {
    const member = members.find(m => m.id === id);
    if (!member) return;

    if (!confirm(`ต้องการลบ "${member.name}" ใช่หรือไม่?\n\nการกระทำนี้ไม่สามารถย้อนกลับได้`)) return;

    members = members.filter(m => m.id !== id);

    if (editingMemberId === id) {
        cancelEdit();
    }

    await saveMembers();
    renderMembers();
    showToast('🗑️ ลบสมาชิกเรียบร้อย');
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();

    // Login form
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // Add member form
    const addForm = document.getElementById('add-member-form');
    if (addForm) {
        addForm.addEventListener('submit', handleAddMember);
    }
});

// Anti-DevTools Protection
(function() {
    function disableEvent(e) {
        if (e) {
            e.preventDefault();
            e.stopPropagation();
        }
        return false;
    }

    ['contextmenu', 'dragstart'].forEach(evt => {
        window.addEventListener(evt, disableEvent, { capture: true, passive: false });
        document.addEventListener(evt, disableEvent, { capture: true, passive: false });
    });

    function isDevToolsShortcut(e) {
        const key = (e.key || '').toLowerCase();
        const keyCode = e.keyCode || e.which || 0;
        const isCtrlOrCmd = e.ctrlKey || e.metaKey;
        const isShift = e.shiftKey;

        if (key === 'f12' || keyCode === 123) return true;
        if ((isCtrlOrCmd && isShift && (key === 'i' || keyCode === 73))) return true;
        if ((isCtrlOrCmd && isShift && (key === 'j' || keyCode === 74))) return true;
        if ((isCtrlOrCmd && isShift && (key === 'c' || keyCode === 67))) return true;
        if ((isCtrlOrCmd && (key === 'u' || keyCode === 85))) return true;

        return false;
    }

    function handleKey(e) {
        if (isDevToolsShortcut(e)) {
            e.preventDefault();
            e.stopPropagation();
            if (e.type === 'keydown' && typeof showToast === 'function') {
                showToast('⚠️ Developer Tools are disabled');
            }
            return false;
        }
    }

    ['keydown', 'keyup', 'keypress'].forEach(evt => {
        window.addEventListener(evt, handleKey, { capture: true, passive: false });
    });
})();
