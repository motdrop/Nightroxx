// Particle cursor trail effect
const cursorTrail = [];
const maxTrailLength = 20;

document.addEventListener('mousemove', (e) => {
    const particle = document.createElement('div');
    particle.className = 'cursor-particle';
    particle.style.cssText = `
        position: fixed;
        width: 6px;
        height: 6px;
        background: #00d9ff;
        border-radius: 50%;
        pointer-events: none;
        z-index: 9998;
        left: ${e.clientX}px;
        top: ${e.clientY}px;
        box-shadow: 0 0 10px rgba(0, 217, 255, 0.8);
        animation: particleFade 0.8s ease-out forwards;
    `;
    document.body.appendChild(particle);

    cursorTrail.push(particle);

    if (cursorTrail.length > maxTrailLength) {
        const oldParticle = cursorTrail.shift();
        if (oldParticle && oldParticle.parentNode) {
            oldParticle.parentNode.removeChild(oldParticle);
        }
    }

    setTimeout(() => {
        if (particle.parentNode) {
            particle.parentNode.removeChild(particle);
        }
    }, 800);
});

// Add particle fade animation
const style = document.createElement('style');
style.textContent = `
    @keyframes particleFade {
        0% {
            opacity: 1;
            transform: scale(1);
        }
        100% {
            opacity: 0;
            transform: scale(0.3) translateY(-30px);
        }
    }
`;
document.head.appendChild(style);

// Ripple effect on card click
document.addEventListener('click', (e) => {
    if (e.target.closest('.card')) {
        const card = e.target.closest('.card');
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const ripple = document.createElement('span');
        ripple.style.cssText = `
            position: absolute;
            width: 20px;
            height: 20px;
            background: rgba(0, 217, 255, 0.5);
            border-radius: 50%;
            left: ${x}px;
            top: ${y}px;
            transform: translate(-50%, -50%) scale(0);
            animation: rippleEffect 0.6s ease-out;
            pointer-events: none;
            z-index: 100;
        `;

        card.style.position = 'relative';
        card.appendChild(ripple);

        setTimeout(() => {
            if (ripple.parentNode) {
                ripple.parentNode.removeChild(ripple);
            }
        }, 600);
    }
});

// Add ripple animation
const rippleStyle = document.createElement('style');
rippleStyle.textContent = `
    @keyframes rippleEffect {
        to {
            transform: translate(-50%, -50%) scale(20);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);

// Magnetic effect for buttons
document.querySelectorAll('.nav-btn, .landing-btn, .music-btn').forEach(btn => {
    btn.addEventListener('mousemove', (e) => {
        const rect = btn.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;

        btn.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px) scale(1.05)`;
    });

    btn.addEventListener('mouseleave', () => {
        btn.style.transform = '';
    });
});

// Floating animation for section icons
document.querySelectorAll('.section-icon').forEach((icon, index) => {
    icon.style.animationDelay = `${index * 0.2}s`;
});

// Stagger animation for cards
document.querySelectorAll('.card').forEach((card, index) => {
    card.style.animationDelay = `${index * 0.05}s`;
});

// Add smooth entrance for sections
const sections = document.querySelectorAll('.section');
const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, {
    threshold: 0.1
});

sections.forEach(section => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(50px)';
    section.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    sectionObserver.observe(section);
});

// Text glitch effect on hover for titles
document.querySelectorAll('.section-title').forEach(title => {
    title.addEventListener('mouseenter', () => {
        title.style.animation = 'none';
        setTimeout(() => {
            title.style.animation = 'titlePulse 3s ease-in-out infinite, glitchEffect 0.3s ease';
        }, 10);
    });
});

const glitchStyle = document.createElement('style');
glitchStyle.textContent = `
    @keyframes glitchEffect {
        0%, 100% { transform: translate(0); }
        25% { transform: translate(-2px, 2px); }
        50% { transform: translate(2px, -2px); }
        75% { transform: translate(-2px, -2px); }
    }
`;
document.head.appendChild(glitchStyle);

console.log('🔥 NIGHTROX - Advanced effects loaded');
